
AUTHOR: Soumitra Samanta (soumitra.samanta@gm.rkmvu.ac.in)
-----------------------------------------------------------------------------
First rename this folder as follows:
assignment_5_yourfullname
For example: if someone name is Kamal Das then the folder name should be: assignment_5_kamal_das

Now goto the folder "assignment_5_yourfullname" and open the "assignment_5_matrix_computation_exc.ipynb" file in your jupyter notebook and follow the notebook instructions. Please use your previous implementation in assignment_1, assignment_2, assignment_3 and assignment_4 whenever it required in "assignment_5".

After completion your task, you again zip your folder and submit.
-----------------------------------------------------------------------------
For query use the above email-id

Enjoy!
