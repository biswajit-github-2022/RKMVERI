
AUTHOR: Soumitra Samanta (soumitra.samanta@gm.rkmvu.ac.in)
-----------------------------------------------------------------------------
First rename this folder as follows:
assignment_4_yourfullname
For example: if someone name is Kamal Das then the folder name should be: assignment_4_kamal_das

Now goto the folder "assignment_4_yourfullname" and open the "assignment_4_matrix_computation_exc.ipynb" file in your jupyter notebook and follow the notebook instructions. Please use your previous implementation in assignment_1, assignment_2 and assignment_3 whenever it required in "assignment_4".

After completion your task, you again zip your folder and submit.
-----------------------------------------------------------------------------
For query use the above email-id

Enjoy!
