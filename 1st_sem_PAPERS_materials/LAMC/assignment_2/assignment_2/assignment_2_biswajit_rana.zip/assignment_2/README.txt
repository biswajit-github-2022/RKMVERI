AUTHOR: Soumitra Samanta (soumitra.samanta@gm.rkmvu.ac.in)
-----------------------------------------------------------------------------
First rename this folder as follows:
assignment_2_yourfullname
For example: if someone name is Kamal Das then the folder name should be: assignment_2_kamal_das

Now goto the folder "assignment_2_yourfullname" and open the "assignment_2_matrix_computation_exc.ipynb" file in your jupyter notebook and follow the notebook instructions. Please use your "vector dot product and matrix multiplication" implementation in assignment_1 whenever it required in "assignment_2".

After completion your task, you again zip your folder and submit.
-----------------------------------------------------------------------------
For query use the above email-id

Enjoy!
